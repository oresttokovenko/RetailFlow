from .. import Provider as SBNProvider


class Provider(SBNProvider):
    pass
